package com.example.fragmenappspanji;

import android.app.Activity;

public class SecondActivity extends Activity {
}
